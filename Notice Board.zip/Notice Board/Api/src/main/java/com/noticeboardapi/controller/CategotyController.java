package com.noticeboardapi.controller;

import com.noticeboardapi.entity.Category;
import com.noticeboardapi.entity.City;
import com.noticeboardapi.repository.CategoryRepo;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@CrossOrigin("http://localhost:3000")
@RestController
@RequestMapping("/api/SNB")
public class CategotyController {

    @Autowired
    private CategoryRepo categoryRepo;

    @PostMapping("/AddCategory")
    public ResponseEntity<?> AddCategory (@RequestBody Category catObj)
    {
        categoryRepo.save(catObj);
        return new ResponseEntity<>("Added Successfully", HttpStatus.OK);
    }

    @GetMapping("/GetCategories")
    public ResponseEntity<?> GetCategories ()
    {
        return new ResponseEntity<>(categoryRepo.findAll(), HttpStatus.OK);
    }

    @PutMapping("/EditCategory")
    public ResponseEntity<?> EditCategory(@RequestBody @NotNull Category catObj)
    {
        var category = categoryRepo.findById(catObj.getCatid()).orElseThrow(() -> new RuntimeException("Category not found"));
        category.setCatname(catObj.getCatname());
        categoryRepo.save(category);
        return new ResponseEntity<>("Updated Successfully", HttpStatus.OK);

    }
    @DeleteMapping("/DeleteCategory/{catid}")
    public ResponseEntity<String> DeleteCategory(@PathVariable Integer catid)
    {
        var category = categoryRepo.findById(catid).orElseThrow(() -> new RuntimeException("Category not found"));
        categoryRepo.delete(category);
        return new ResponseEntity<>("Deleted Successfully",HttpStatus.OK);

    }
}
