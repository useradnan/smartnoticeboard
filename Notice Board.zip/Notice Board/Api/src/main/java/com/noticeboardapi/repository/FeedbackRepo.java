package com.noticeboardapi.repository;

import com.noticeboardapi.dto.FeedbackDto;
import com.noticeboardapi.entity.Feedback;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface FeedbackRepo extends JpaRepository<Feedback, Integer> {

    @Query("SELECT new com.noticeboardapi.dto.FeedbackDto(f.fid, f.clgid, f.departmentid, f.feedback, f.mobile, f.name, c.clgname, d.departmentname) FROM Feedback f INNER JOIN College c ON f.clgid=c.clgid INNER JOIN Departments d ON f.departmentid=d.departmentid")
    List<FeedbackDto> GetFeedback();
}
