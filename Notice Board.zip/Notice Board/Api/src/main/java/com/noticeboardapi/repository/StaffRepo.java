package com.noticeboardapi.repository;

import com.noticeboardapi.dto.CollegeDto;
import com.noticeboardapi.dto.StaffDto;
import com.noticeboardapi.entity.Staff;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface StaffRepo extends JpaRepository<Staff, String> {


    @Query("SELECT new com.noticeboardapi.dto.StaffDto(stf.clgid,stf.staffid,stf.staffname,stf.staffrole,stf.departmentid,dpt.departmentname) FROM Staff stf INNER JOIN Departments dpt ON stf.departmentid=dpt.departmentid")
    List<StaffDto> GetStaffs();


//Boolean existsByStaffid (String staffid);
//Boolean existsByStaffname (String staffname);
//Boolean existsByStaffrole (String staffrole);
//Boolean existsByDepartmentid (String departmentid);
//Boolean existsByClgid (int clgid);


//    @Query(value = "SELECT COUNT(*) FROM staff WHERE clgid=:clgid AND staffid=:staffid",nativeQuery = true)
//    Integer checkstaffid(@Param("clgid") Integer clgid, @Param("staffid") String staffid);
//
//
//    Optional<Staff> findByStaffid(String staffid);


}
