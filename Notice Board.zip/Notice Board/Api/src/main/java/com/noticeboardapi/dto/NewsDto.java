package com.noticeboardapi.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class NewsDto {
    private int newsid;
    private int clgid;
    private String newsdesc;
    private String newstitle;
    private String clgname;

}
