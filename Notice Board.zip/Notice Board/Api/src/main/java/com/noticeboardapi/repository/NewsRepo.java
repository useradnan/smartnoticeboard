package com.noticeboardapi.repository;

import com.noticeboardapi.dto.NewsDto;
import com.noticeboardapi.entity.News;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface NewsRepo extends JpaRepository<News, Integer> {

    @Query("SELECT new com.noticeboardapi.dto.NewsDto(n.newsid, n.clgid, n.newsdesc, n.newstitle, c.clgname) FROM News n INNER JOIN College c ON n.clgid=c.clgid")
    List<NewsDto> GetNews();
}
