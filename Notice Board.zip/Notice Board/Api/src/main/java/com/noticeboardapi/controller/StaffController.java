package com.noticeboardapi.controller;

import com.noticeboardapi.entity.Staff;
import com.noticeboardapi.repository.StaffRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin("http://localhost:3000")
@RestController
@RequestMapping("/api/SNB")

public class StaffController {

    @Autowired
    private StaffRepo staffRepo;

    @PostMapping("/AddStaff")
    public ResponseEntity<String> AddStaff(@RequestBody Staff objStaff)
    {
        if(staffRepo.existsById(objStaff.getStaffid()))
        {
            throw new RuntimeException("Staff ID Already Exists");
        }

        else {
            staffRepo.save(objStaff);
            return new ResponseEntity<>("Added Successfully", HttpStatus.CREATED);
        }
    }

//    @GetMapping("/GetStaff")
//    public ResponseEntity<List<Staff>> GetStaff()
//    {
//        return new ResponseEntity<>(staffRepo.findAll(),HttpStatus.OK);
//    }

    @PutMapping("/EditStaff")
    public ResponseEntity<String> UpdateStaff (@RequestBody Staff objStaff)
    {
        var staff = staffRepo.findById(objStaff.getStaffid()).orElseThrow(()->new RuntimeException("Staff Not Found"));
        staff.setStaffname(objStaff.getStaffname());
        staff.setStaffrole((objStaff.getStaffrole()));
        staff.setDepartmentid(objStaff.getDepartmentid());
        staffRepo.save(staff);

        return  new ResponseEntity<>("Updated Successfully", HttpStatus.OK);

    }

    @DeleteMapping("/DeleteStaff/{staffid}")
    public ResponseEntity<String> DeleteStaff(@PathVariable String staffid)
    {
        var staff = staffRepo.findById(staffid).orElseThrow(()->new RuntimeException("Staff Not Found"));
        staffRepo.delete(staff);
        return new ResponseEntity<>("Deleted Successfully",HttpStatus.OK);
    }

    @GetMapping("/GetStaff")
    public ResponseEntity<?> GetStaff() {

        return new ResponseEntity<>(staffRepo.GetStaffs(), HttpStatus.OK);
    }
}

