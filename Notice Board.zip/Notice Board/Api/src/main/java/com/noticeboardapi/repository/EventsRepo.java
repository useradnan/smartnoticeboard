package com.noticeboardapi.repository;

import com.noticeboardapi.dto.EventsDto;
import com.noticeboardapi.entity.Events;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface EventsRepo extends JpaRepository<Events, Integer> {

    @Query("SELECT new com.noticeboardapi.dto.EventsDto(e.eventid, e.catid, cat.catname, e.clgid, clg.clgname, e.eventdate, e.eventdesc,e.eventname, e.eventtime) FROM Events e INNER JOIN Category cat ON e.catid=cat.catid INNER JOIN College clg ON e.clgid=clg.clgid")
    List<EventsDto> GetEvents();
}
