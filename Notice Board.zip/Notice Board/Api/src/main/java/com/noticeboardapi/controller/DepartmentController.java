package com.noticeboardapi.controller;

import com.noticeboardapi.entity.Departments;
import com.noticeboardapi.repository.CollegeRepo;
import com.noticeboardapi.repository.DepartmentRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@CrossOrigin("http://localhost:3000")
@RestController
@RequestMapping("/api/SNB")
public class DepartmentController {

    @Autowired
    private DepartmentRepo departmentRepo;

    @Autowired
    private CollegeRepo collegeRepo;

    @PostMapping("/AddDepartments")

    public ResponseEntity<String> AddDepartments(@RequestBody Departments objDpt)
    {
//        var clg = collegeRepo.findById(objDpt.getClgid()).orElseThrow(()->new RuntimeException("College not found"));
//        objDpt.setObjClg(clg);

        if(departmentRepo.existsById(objDpt.getDepartmentid()))
        {
                throw new RuntimeException("Department Already exists");
        }
        else
        {
            departmentRepo.save(objDpt);
            return new ResponseEntity<>("Added Successfully", HttpStatus.CREATED);
        }

    }

    @GetMapping("/GetDepartments")
    public ResponseEntity<?> GetDepartments()
    {
        return new ResponseEntity<>(departmentRepo.findAll(),HttpStatus.OK);
    }

    @DeleteMapping("/DeleteDpt/{departmentid}")
    public ResponseEntity<String> DeleteDepartment(@PathVariable String departmentid)
    {
        var dpt = departmentRepo.findById(departmentid).orElseThrow(()->new RuntimeException("Department not found"));

            departmentRepo.delete(dpt);
            return new ResponseEntity<>("Deleted Successfully", HttpStatus.OK);
    }

    @PutMapping("/EditDepartment")
    public ResponseEntity<String> EditDepartment(@RequestBody Departments objDpt)
    {
        var dpt = departmentRepo.findById(objDpt.getDepartmentid()).orElseThrow(()-> new RuntimeException("Department not found"));
        dpt.setDepartmentname(objDpt.getDepartmentname());
        departmentRepo.save(dpt);
        return new ResponseEntity<>("Updated Successfully",HttpStatus.OK);
    }

    @GetMapping("GetDepartment/{clgid}")
    public ResponseEntity<?> GetDpt (@PathVariable Integer clgid)
    {
        return new ResponseEntity<>(departmentRepo.findByClgid(clgid),HttpStatus.OK);
    }
}
