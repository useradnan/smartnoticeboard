package com.noticeboardapi.controller;

import com.noticeboardapi.entity.Images;
import com.noticeboardapi.repository.EventsRepo;
import com.noticeboardapi.repository.ImagesRepo;
import jakarta.servlet.Servlet;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StreamUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Arrays;

@CrossOrigin("http://localhost:3000")
@RestController
@RequestMapping("/api/SNB")
public class ImageController {

    @Autowired
    private ImagesRepo imagesRepo;
    @Autowired
    private EventsRepo eventsRepo;

    @PostMapping("/UploadImage/{eventid}")
    public ResponseEntity<?> UploadImage(@RequestParam("images") MultipartFile[] images, @PathVariable Integer eventid)
    {
        var event = eventsRepo.findById(eventid).orElseThrow(()-> new RuntimeException("Event Not Found"));

        Arrays.stream(images).forEach(image->{
            try {
                Images imagesentity = new Images();
                imagesentity.setFile(image.getBytes());
                imagesentity.setImgname(image.getOriginalFilename());
                imagesentity.setEvent(event);
                imagesRepo.save(imagesentity);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });
        return new ResponseEntity<>("Event Added Successfully", HttpStatus.CREATED);
    }

    @GetMapping("/GetImages/{imgid}")
    public ResponseEntity<?> GetImages(@PathVariable Integer imgid, HttpServletResponse response) throws IOException {
        var img = imagesRepo.findById(imgid).orElseThrow(()-> new RuntimeException("Image Not Found"));
        ByteArrayInputStream inputStream = new ByteArrayInputStream(img.getFile());

        response.setContentType(MediaType.IMAGE_JPEG_VALUE);
        StreamUtils.copy(inputStream, response.getOutputStream());

        return new ResponseEntity<>("Success", HttpStatus.OK);
    }


    @GetMapping("/GetImagesByEvent/{eventid}")
    public ResponseEntity<?> GetImagesByEvent(@PathVariable Integer eventid)  {

        var event = eventsRepo.findById(eventid).orElseThrow(()-> new RuntimeException("Event Not Found"));

        var img = imagesRepo.findByEvent(event);

        var imagelist = img.stream().map(image->
        {
           return ServletUriComponentsBuilder.fromCurrentContextPath().path("/api/SNB/GetImages/").path(String.valueOf(image.getImageid())).toUriString();
        }).toList();

        return new ResponseEntity<>(imagelist, HttpStatus.OK);
    }
}
