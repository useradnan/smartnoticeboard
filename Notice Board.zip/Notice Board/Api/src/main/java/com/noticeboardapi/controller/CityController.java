package com.noticeboardapi.controller;


import com.noticeboardapi.entity.City;
import com.noticeboardapi.repository.CityRepo;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@CrossOrigin("http://localhost:3000")
@RestController
@RequestMapping("/api/SNB")


public class CityController {
    @Autowired
    private CityRepo cityRepo;

    @PostMapping("/AddCity")
    public ResponseEntity<String> addCity(@RequestBody @NotNull City cityObj) {
            cityRepo.save(cityObj);
            return new ResponseEntity<>("Added Successfully", HttpStatus.CREATED);

    }
    @GetMapping("/GetCities")
    public ResponseEntity<?> GetCities() {
        return new ResponseEntity<>(cityRepo.findAll(), HttpStatus.OK);
    }


    @PutMapping("/EditCity")
    public ResponseEntity<?> EditCity(@RequestBody @NotNull City cityObj)
    {
        var city = cityRepo.findById(cityObj.getCityid()).orElseThrow(() -> new RuntimeException("City not found"));
        city.setCityname(cityObj.getCityname());
        cityRepo.save(city);
        return new ResponseEntity<>("Updated Successfully", HttpStatus.OK);

    }
    @DeleteMapping("/DeleteCity/{cityid}")
    public ResponseEntity<String> DeleteCity(@PathVariable Integer cityid)
    {
        var city = cityRepo.findById(cityid).orElseThrow(() -> new RuntimeException("City not found"));
        cityRepo.delete(city);
        return new ResponseEntity<>("Deleted Successfully",HttpStatus.OK);

    }
}
