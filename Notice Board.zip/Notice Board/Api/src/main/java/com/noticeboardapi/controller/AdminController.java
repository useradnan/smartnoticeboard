package com.noticeboardapi.controller;

import com.noticeboardapi.dto.LoginDto;
import com.noticeboardapi.dto.PasswordDto;
import com.noticeboardapi.entity.AdminLogin;
import com.noticeboardapi.entity.College;
import com.noticeboardapi.repository.AdminRepo;
import com.noticeboardapi.repository.CollegeRepo;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@CrossOrigin("http://localhost:3000")
@RestController
@RequestMapping("/api/SNB")


public class AdminController {

    @Autowired
    private AdminRepo adminRepo;

    @Autowired
    private CollegeRepo collegeRepo;

    @PostMapping("/Login")
    public ResponseEntity<?> adminLogin(@RequestBody @NotNull LoginDto loginObj) {

        if(loginObj.getUsertype().equals("Admin"))
        {

            AdminLogin existingAdmin = adminRepo.findById(loginObj.getUserid())
                    .orElseThrow(() -> new RuntimeException("User not found"));
            if (!existingAdmin.getPassword().equals(loginObj.getPassword())) {
                throw new RuntimeException("Invalid Password");
            }
            else {
                return new ResponseEntity<>("Success", HttpStatus.OK);
            }

        }
        else if(loginObj.getUsertype().equals("College"))
        {

            College existingCollege = collegeRepo.findById(loginObj.getUserid())
                    .orElseThrow(() -> new RuntimeException("User not found"));
            if (!existingCollege.getPassword().equals(loginObj.getPassword())) {
                throw new RuntimeException("Invalid Password");
            }
            else {
                return new ResponseEntity<>("Success", HttpStatus.OK);

            }

        }
        else {
            return new ResponseEntity<>("Something went wrong!!!", HttpStatus.BAD_REQUEST);
        }

    }


    @PutMapping("/ChangeAdminPass/{id}")
    public ResponseEntity<?> ChangeAdminPass(@RequestBody @NotNull PasswordDto passObj,@PathVariable Integer id)
    {
        var admin = adminRepo.findById(id).orElseThrow(() -> new RuntimeException("User not found"));

        if (!admin.getPassword().equals(passObj.getOldpassword())) {
            throw new RuntimeException("Invalid Password");
        }
        else {
            admin.setPassword(passObj.getNewpassword());
            adminRepo.save(admin);
            return new ResponseEntity<>("Password Updated Successfully", HttpStatus.OK);
        }

    }

}
