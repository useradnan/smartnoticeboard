package com.noticeboardapi.controller;

import com.noticeboardapi.entity.News;
import com.noticeboardapi.repository.NewsRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@CrossOrigin("http://localhost:3000")
@RestController
@RequestMapping("/api/SNB")

public class NewsController {
    @Autowired
    private NewsRepo newsRepo;
    @PostMapping("/AddNews")
    public ResponseEntity<String> AddNews (@RequestBody News objNews)
    {
      newsRepo.save(objNews);
      return new ResponseEntity<>("News Added Successfully", HttpStatus.CREATED);
    }

    @DeleteMapping("/DeleteNews/{newsid}")
    public ResponseEntity<String> DeleteNews(@PathVariable Integer newsid)
    {
        var news = newsRepo.findById(newsid).orElseThrow(()->new RuntimeException("News Not Found"));
        newsRepo.delete(news);
        return new ResponseEntity<>("News deleted",HttpStatus.OK);
    }

    @GetMapping("/GetNews")
    public ResponseEntity<?> GetNews()
    {
        return new ResponseEntity<>(newsRepo.GetNews(),HttpStatus.OK);
    }
}
