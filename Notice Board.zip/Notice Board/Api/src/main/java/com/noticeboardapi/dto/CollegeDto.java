package com.noticeboardapi.dto;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class CollegeDto {

    private int clgid;
    private String clgname;
    private String clgmob;
    private int cityid;
    private String password;
    private String cityname;

}
