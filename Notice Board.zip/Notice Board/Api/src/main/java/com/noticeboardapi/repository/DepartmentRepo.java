package com.noticeboardapi.repository;

import com.noticeboardapi.entity.Departments;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface DepartmentRepo extends JpaRepository<Departments, String> {

    Boolean existsByDepartmentid(String id);
    Boolean existsByDepartmentname(String name);
    Boolean existsByClgid(Integer clgid);

    Optional<Departments> findByDepartmentid(String did);
    List<Departments> findByClgid(Integer clgid);

    @Query(value = "SELECT count(*) FROM departments WHERE clgid=:clgid AND departmentid=:departmentid",nativeQuery = true)
    Integer checkdptid(@Param("clgid") Integer clgid, @Param("departmentid") String departmentid);

    @Query(value = "SELECT count(*) FROM departments WHERE clgid=:clgid AND departmentid=:departmentid AND departmentname=:departmentname",nativeQuery = true)
    Integer checkidname(@Param("clgid") Integer clgid, @Param("departmentid") String departmentid, @Param("departmentname") String departmentname);
}
