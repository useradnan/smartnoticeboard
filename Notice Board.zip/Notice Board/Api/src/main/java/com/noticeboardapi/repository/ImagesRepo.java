package com.noticeboardapi.repository;

import com.noticeboardapi.entity.Events;
import com.noticeboardapi.entity.Images;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ImagesRepo extends JpaRepository<Images, Integer> {

    List<Images>findByEvent(Events objEvent);
}
