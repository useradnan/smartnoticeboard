package com.noticeboardapi.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class EventsDto {

    private int eventid;
    private  int catid;
    private  String catname;
    private int clgid;
    private String clgname;
    private String eventdate;
    private String eventdesc;
    private String eventname;
    private String eventtime;




}
