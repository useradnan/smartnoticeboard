package com.noticeboardapi.controller;

import com.noticeboardapi.entity.Feedback;
import com.noticeboardapi.repository.FeedbackRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin("http://localhost:3000")
@RequestMapping("/api/SNB")
@RestController

public class FeedbackController {

    @Autowired
    private FeedbackRepo feedbackRepo;

    @PostMapping("/PostFeedback")
    public ResponseEntity<String> PostFeedback(@RequestBody Feedback objFeedback)
    {
        feedbackRepo.save(objFeedback);
        return new ResponseEntity<>("Feedback Posted Successfully", HttpStatus.CREATED);
    }

    @GetMapping("/GetFeedback")
    public ResponseEntity<?> GetFeedbac()
    {
        return new ResponseEntity<>(feedbackRepo.GetFeedback(),HttpStatus.OK);
    }
}
