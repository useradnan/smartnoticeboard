package com.noticeboardapi.repository;

import com.noticeboardapi.entity.City;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CityRepo extends JpaRepository<City, Integer> {
}
