package com.noticeboardapi.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class FeedbackDto {

    private int fid;
    private int clgid;
    private String departmentid;
    private String feedback;
    private long mobile;
    private String name;
    private String clgname;
    private String departmentname;
}
