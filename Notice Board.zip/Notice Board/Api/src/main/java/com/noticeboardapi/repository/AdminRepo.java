package com.noticeboardapi.repository;

import com.noticeboardapi.entity.AdminLogin;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AdminRepo extends JpaRepository<AdminLogin,Integer> {
}
