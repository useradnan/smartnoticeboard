package com.noticeboardapi.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
//@Table(name = "admin_login")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor

public class AdminLogin {

    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)       //Auto increament
    private int userid;

    private String password;
}
