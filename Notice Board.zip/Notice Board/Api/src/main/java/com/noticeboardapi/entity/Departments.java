package com.noticeboardapi.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor

public class Departments {


    @Id
    private String departmentid;

    private String departmentname;

    private int clgid;

//    @OneToOne(cascade = CascadeType.ALL)
//   @JoinColumn(name = "clgid")
//    private College objClg;
}
