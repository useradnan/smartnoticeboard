package com.noticeboardapi.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class StaffDto {
    private int clgid;
    private String staffid;
    private String staffname;
    private String staffrole;
    private String departmentid;
    private String departmentname;

}
