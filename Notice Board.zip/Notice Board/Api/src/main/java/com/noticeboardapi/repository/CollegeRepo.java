package com.noticeboardapi.repository;

import com.noticeboardapi.dto.CollegeDto;
import com.noticeboardapi.entity.College;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface CollegeRepo extends JpaRepository<College, Integer> {


    @Query
    ("SELECT new com.noticeboardapi.dto.CollegeDto(clg.clgid,clg.clgname,clg.clgmob,clg.cityid,clg.password,ct.cityname) FROM College clg INNER JOIN City ct ON clg.cityid=ct.cityid")
    List<CollegeDto> GetClgWithCity();


//    @Query
//            ("SELECT new com.noticeboardapi.dto.CollegeDto(clg.clgid,clg.clgname,clg.clgmob,clg.cityid,clg.password,ct.cityname) FROM College clg INNER JOIN City ct ON clg.cityid=ct.cityid where ct.cityid=:id")
//    CollegeDto GetClgWithCityCondtion(@Param("id") Integer cityid);


}
