package com.noticeboardapi.controller;

import com.noticeboardapi.entity.Events;
import com.noticeboardapi.repository.EventsRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin("http://localhost:3000")
@RestController
@RequestMapping("/api/SNB")

public class EventsController {

    @Autowired
    private EventsRepo eventsRepo;

    @PostMapping("/AddEvent")
    public ResponseEntity<?> AddEvent(@RequestBody Events objEvents)
    {
        return new ResponseEntity<>(eventsRepo.save(objEvents), HttpStatus.CREATED);
    }

    @DeleteMapping("/DeleteEvent/{eventid}")
    public ResponseEntity<String> DeleteEvent(@PathVariable Integer eventid)
    {
        var event = eventsRepo.findById(eventid).orElseThrow(()->new RuntimeException("Event Not Found!!!"));
        eventsRepo.delete(event);
        return new ResponseEntity<>("Event Deleted Successfully", HttpStatus.OK);
    }

    @GetMapping("/GetEvents")
    public ResponseEntity<List<Events>> GetEvents()
    {
        return new ResponseEntity<>(eventsRepo.findAll(),HttpStatus.OK);
    }


    @GetMapping("/GetAllEvents")
    public  ResponseEntity<?> GetAllEvents()
    {
        return new ResponseEntity<>(eventsRepo.GetEvents(),HttpStatus.OK);
    }
}
