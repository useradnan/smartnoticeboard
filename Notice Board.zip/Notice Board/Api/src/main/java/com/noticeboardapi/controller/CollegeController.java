package com.noticeboardapi.controller;

import com.noticeboardapi.dto.PasswordDto;
import com.noticeboardapi.entity.College;
import com.noticeboardapi.repository.CityRepo;
import com.noticeboardapi.repository.CollegeRepo;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@CrossOrigin("http://localhost:3000")
@RestController
@RequestMapping("/api/SNB")


public class CollegeController {

    @Autowired
    private CollegeRepo collegeRepo;

    @PostMapping("/AddCollege")
    public ResponseEntity<?> AddClg(@RequestBody @NotNull College clgObj) {
        collegeRepo.save(clgObj);
        return new ResponseEntity<>("Added Succesfully", HttpStatus.CREATED);
    }

    @PutMapping("/EditCollege")
    public ResponseEntity<?> EditClg(@RequestBody @NotNull College clgObj) {
        var clg = collegeRepo.findById(clgObj.getClgid()).orElseThrow(() -> new RuntimeException("College not found"));
        clg.setClgname(clgObj.getClgname());
        clg.setCityid(clgObj.getCityid());
        clg.setClgmob(clgObj.getClgmob());
        clg.setPassword(clgObj.getPassword());
        collegeRepo.save(clg);
        return new ResponseEntity<>("Updated Successfully", HttpStatus.OK);
    }


    @GetMapping("/GetCollege")
    public ResponseEntity<?> GetCollege() {
        return new ResponseEntity<>(collegeRepo.GetClgWithCity(), HttpStatus.OK);
    }

    @DeleteMapping("/DeleteClg/{clgid}")
    public ResponseEntity<String> DeleteCity(@PathVariable Integer clgid) {
        var city = collegeRepo.findById(clgid).orElseThrow(() -> new RuntimeException("City not found"));
        collegeRepo.delete(city);
        return new ResponseEntity<>("Deleted Successfully", HttpStatus.OK);

    }


    @PutMapping("/ChangeClgPass/{id}")
    public ResponseEntity<?> ChangeAdminPass(@RequestBody @NotNull PasswordDto passObj, @PathVariable Integer id)
    {
        var college = collegeRepo.findById(id).orElseThrow(() -> new RuntimeException("College not found"));

        if (!college.getPassword().equals(passObj.getOldpassword())) {
            throw new RuntimeException("Invalid Password");
        }
        else {
            college.setPassword(passObj.getNewpassword());
            collegeRepo.save(college);
            return new ResponseEntity<>("Password Updated Successfully", HttpStatus.OK);
        }

    }


    @PutMapping("/UpdateClgProfile/{id}")
    public ResponseEntity<?> UpdateClgProfile(@RequestBody @NotNull College clgObj, @PathVariable Integer id) {
        var clg = collegeRepo.findById(id).orElseThrow(() -> new RuntimeException("College not found"));
        clg.setClgname(clgObj.getClgname());
        clg.setCityid(clgObj.getCityid());
        clg.setClgmob(clgObj.getClgmob());
        collegeRepo.save(clg);
        return new ResponseEntity<>("Updated Successfully", HttpStatus.OK);
    }
}
