package com.noticeboardapi.Exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(RuntimeException.class)
    public ResponseEntity<?> HandleException (RuntimeException exceptionObj)
    {
        return new ResponseEntity<>(exceptionObj.getMessage(), HttpStatus.BAD_REQUEST);
    }
}
