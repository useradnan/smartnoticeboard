import React, { createContext, useContext, useEffect, useState } from "react";

const context = createContext();
export const CustomContext = () => useContext(context);

export default function Context({ children }) {
  const [userid, setuserid] = useState("");

  useEffect(() => {
    const id = sessionStorage.getItem("userid");
    setuserid(id);
  }, []);
  return <context.Provider value={{ userid }}>{children}</context.Provider>;
}
