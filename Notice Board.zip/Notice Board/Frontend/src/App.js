
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import { ToastContainer } from 'react-toastify';
import './App.css';
import AdminDashboard from './Components/Admin/AdminDashboard';
import ChangePassword from './Components/Admin/ChangePassword';
import Cities from './Components/Admin/Cities';
import Colleges from './Components/Admin/Colleges';
import Eventcategory from './Components/Admin/Eventcategory';
import CollegeDashboard from './Components/College/CollegeDashboard';
import ManageDepartments from './Components/College/ManageDepartments';
import ManageEvents from './Components/College/ManageEvents';
import ManageStaff from './Components/College/ManageStaff';
import HomeColleges from './Components/Home/Colleges';
import PublicFeedback from './Components/Home/PublicFeedback';
import Home from './Components/Home/Home';
import Login from './Components/Home/Login';
import Context from './ContextApi/ContextApi';
import PostNews from './Components/College/PostNews';
import ViewClgFeedback from './Components/College/ViewClgFeedback';
import ViewFeedback from './Components/Admin/ViewFeedback';
import HomeEvents from './Components/Home/HomeEvents';
import HomeNews from './Components/Home/HomeNews';
import HomeDepartments from './Components/Home/HomeDepartments';
import About from './Components/Home/about';

export const baseUrl = "http://localhost:8080/api/SNB"

function App() {
  return (
    <BrowserRouter>
    <ToastContainer/>
    {/* <Home/> */}
    <Routes>
      <Route path='/' element={<Home />}>

      <Route path='Login' element={<Login />} />
      <Route path='HomeClg' element={<HomeColleges />} />
      <Route path='HomeEvents' element={<HomeEvents />} />
      <Route path='HomeNews' element={<HomeNews />} />
      <Route path='HomeDepartments' element={<HomeDepartments />} />
      <Route path='Feedback' element={<PublicFeedback />} />
      <Route path='About' element={<About />} />

      </Route>
   

      <Route path='/AdminDash' element={<AdminDashboard/>}>

      <Route path='Cities' element={<Cities />} />
      <Route path='Colleges' element={<Colleges />} />
      <Route path='EventCategory' element={<Eventcategory />} />
      <Route path='ViewFeedback' element={<ViewFeedback />} />
      <Route path='ChangePass' element={<ChangePassword />} />

      </Route>

      <Route path='/ClgDash' element={<CollegeDashboard/>}>

      <Route path='ManageDepartments' element={<ManageDepartments />} />
      <Route path='ManageStaff' element={<ManageStaff />} />
      <Route path='ManageEvents' element={<ManageEvents />} />
      <Route path='PostNews' element={<PostNews />} />
      <Route path='ViewClgFeedback' element={<ViewClgFeedback />} />

      </Route>

    </Routes>
    </BrowserRouter>
  );
}

export default App;
