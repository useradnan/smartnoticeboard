import React, { useState } from 'react'
import { Container, Nav, Navbar } from 'react-bootstrap'
import { Link } from 'react-router-dom'
import ChangePassword from './ChangePassword';

export default function AdminHeader() {
  const [show, setShow] = useState(false);

  const id = sessionStorage.getItem('userid');

  const toggle = () => setShow(!show);
  return (
    <div>
      <Navbar collapseOnSelect expand="lg" bg="dark" variant="dark">
        <Container fluid>
          <Navbar.Brand href="/">Notice Board</Navbar.Brand>
          <Navbar.Toggle aria-controls="responsive-navbar-nav" />
          <Navbar.Collapse id="responsive-navbar-nav">
            <Nav className="me-auto">
              <Nav.Link as={Link} to='/AdminDash/Cities' className="ms-1">Manage Cities</Nav.Link>
              <Nav.Link as={Link} to='/AdminDash/Colleges' className="ms-1">Manage Colleges</Nav.Link>
              <Nav.Link as={Link} to='/AdminDash/EventCategory' className="ms-1">Manage Event Categories</Nav.Link>
              <Nav.Link as={Link} to='/AdminDash/ViewFeedback' className="ms-1">View Feedback</Nav.Link>
              <Nav.Link onClick={toggle} className="ms-1" >Change Password</Nav.Link>
              <ChangePassword show={show} toggle={toggle} userid={id}/>
            </Nav>
            <Nav>
              <Nav.Link as={Link} to='/' className="me-1">Logout</Nav.Link>
            </Nav>
          </Navbar.Collapse>
        </Container>
      </Navbar>
    </div>
  )
}
