import axios from "axios";
import React, { useEffect, useState } from "react";
import { FiEdit } from "react-icons/fi";
import { RiDeleteBin5Line } from "react-icons/ri";
import { toast } from "react-toastify";
import { baseUrl } from "../../App";

export default function Colleges() {
  const [cityid, setCityId] = useState("");

  const [clgid, setClgId] = useState("");
  const [clgname, setClgName] = useState("");
  const [clgmob, setClgMob] = useState("");
  const [password, setClgPass] = useState("");

  const [cities, setCities] = useState([]);

  const [clglist, setclglist] = useState([]);

  const [valcity, setValcity] = useState(false);

  const [valname, setvalname] = useState(false);

  const [valmobile, setValMobile] = useState(false);

  const [valpass, setValPass] = useState(false);

  const [update, setUpdate] = useState(false);

  useEffect(() => {
    GetCities();
    GetColleges();
  }, []);

  function GetCities() {
    axios
      .get(baseUrl + "/GetCities")
      .then((res) => {
        setCities(res.data);
      })
      .catch((error) => {
        console.log(error);
      });
  }

  function EditClg(clgid) {
    const array = clglist.filter((clg) => clg.clgid === clgid);

    setCityId(array[0].cityid);
    setClgName(array[0].clgname);
    setClgMob(array[0].clgmob);
    setClgPass(array[0].password);
    setClgId(array[0].clgid);

    setUpdate(true)
  }

  function DeleteClg(clgid) {
    if (window.confirm("Are you sure!!! to Delete it?")) {
      axios
        .delete(baseUrl + `/DeleteClg/${clgid}`)
        .then((res) => {
          toast.success(res.data);
          // const arr = cities.filter((city) => city.cityid !== id);
          // setCities(arr);
          GetColleges();
        })
        .catch((err) => {
          console.log(err);
        });
    }
  }

  function GetColleges() {
    axios
      .get(baseUrl + "/GetCollege")
      .then((res) => {
        setclglist(res.data);
      })
      .catch((err) => {
        console.log(err);
      });
  }

  function AddCollege() {
    debugger;
    const data = {
      clgname: clgname,
      cityid: cityid,
      clgmob: clgmob,
      password: password,
    };
    if (cityid === "") {
      setValcity(true);
    } else if (clgname === "") {
      setvalname(true);
    } else if (clgmob === "") {
      setValMobile(true);
    } else if (password === "") {
      setValPass(true);
    } else {
      axios
        .post(baseUrl + "/AddCollege", data)
        .then((res) => {
          debugger;
          toast.success(res.data);
          GetColleges();
          ClearAll();
        })
        .catch((error) => {
          console.log(error);
        });
    }
  }

  function EditCollege() {
    debugger;
    const data = {
      clgname: clgname,
      cityid: cityid,
      clgmob: clgmob,
      password: password,
      clgid: clgid,
    };
    if (cityid === "") {
      setValcity(true);
    } else if (clgname === "") {
      setvalname(true);
    } else if (clgmob === "") {
      setValMobile(true);
    } else if (password === "") {
      setValPass(true);
    } else {
      axios
        .put(baseUrl + "/EditCollege", data)
        .then((res) => {
          debugger;
          toast.success(res.data);
          GetColleges();
          ClearAll();
        })
        .catch((error) => {
          console.log(error);
        });
    }
  }

  function ClearAll() {
    setClgId("");
    setCityId("");
    setClgName("");
    setClgMob("");
    setClgPass("");
    setClgPass("");
    setValcity(false);
    setvalname(false);
    setValMobile(false);
    setValPass(false);
  }

  return (
    <div>
      <div className="container mt-5">
        <div className="row">
          <div className="col-lg-6">
            <div className="card ">
              <div className="card-header">
                <h3 className="card-title">Add College</h3>
              </div>
              <form className="emp-form">
                <div className="card-body">
                  <div className="form-group mt-3">
                    <label htmlFor="select">Select City</label>
                    <select
                      className="form-select text-center"
                      name="userType"
                      onChange={(e) => setCityId(e.target.value)}
                      value={cityid}
                    >
                      <option className="form-control" value={0}>
                        ----Select City----
                      </option>
                      {cities.map((element, index) => {
                        return (
                          <option
                            className="form-control"
                            key={index}
                            value={element.cityid}
                          >
                            {element.cityname}
                          </option>
                        );
                      })}
                    </select>
                    {valcity && (
                      <small id="useridhelp" className="form-text text-danger">
                        Select City
                      </small>
                    )}
                  </div>

                  <div className="form-group mt-3">
                    <label>Enter College Name</label>
                    <input
                      type="text"
                      className="form-control"
                      name="clgname"
                      required
                      value={clgname}
                      onChange={(e) => setClgName(e.target.value)}
                    />
                    {valname && (
                      <small id="useridhelp" className="form-text text-danger">
                        Enter College Name
                      </small>
                    )}
                  </div>
                  <div className="form-group mt-3">
                    <label>Enter Mob.No</label>
                    <input
                      type="text"
                      className="form-control"
                      name="clgmob"
                      required
                      value={clgmob}
                      onChange={(e) => setClgMob(e.target.value)}
                    />
                    {valmobile && (
                      <small id="useridhelp" className="form-text text-danger">
                        Enter Mobile No.
                      </small>
                    )}
                  </div>

                  <div className="form-group mt-3">
                    <label>Enter Passward</label>
                    <input
                      type="password"
                      className="form-control"
                      name="clgpass"
                      required
                      value={password}
                      onChange={(e) => setClgPass(e.target.value)}
                    />
                    {valpass && (
                      <small id="useridhelp" className="form-text text-danger">
                        Enter Password
                      </small>
                    )}
                  </div>
                </div>

                <div className="card-footer">
                  <div className="form-row">
                    <a
                      onClick={ClearAll}
                      href
                      className="d-flex"
                      style={{ cursor: "pointer" }}
                    >
                      Reset
                    </a>
                    <div className="form-group ">
                      <button
                        type="button"
                        className="btn btn-primary d-flex ms-auto"
                        onClick={clgid?EditCollege:AddCollege}
                      >
                        {update ? "Update College" : "Add College"}
                      </button>
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>

          <div className="col-lg-6">
            <div className="card">
              <div className="card-header">
                <h3 className="panel-title">Added College</h3>
              </div>
              <div className="card-body">
                <table className="table">
                  <tr>
                    <th>College Id</th>
                    <th>College Name</th>
                    <th>College City</th>
                    <th>College Mobile</th>
                    <th></th>
                    <th></th>
                  </tr>
                  <tbody>
                    {clglist.map((clg, index) => {
                      return (
                        <tr key={index}>
                          <td>{clg.clgid}</td>
                          <td>{clg.clgname}</td>
                          <td>{clg.cityname}</td>
                          <td>{clg.clgmob}</td>
                          <td>
                            <FiEdit
                              onClick={() => EditClg(clg.clgid)}
                              style={{ cursor: "pointer" }}
                              color="green"
                              size={"1.5rem"}
                            ></FiEdit>
                          </td>
                          <td>
                            <RiDeleteBin5Line
                              style={{ cursor: "pointer" }}
                              color="red"
                              size={"1.5rem"}
                              onClick={() => DeleteClg(clg.clgid)}
                            ></RiDeleteBin5Line>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
