import axios from "axios";
import React, { useEffect, useState } from "react";
import { toast } from "react-toastify";
import { baseUrl } from "../../App";
import { FiEdit } from "react-icons/fi";
import { RiDeleteBin5Line } from "react-icons/ri";

export default function Eventcategory() {

  const [catname , setCategory] = useState("");

  const [catid, setCatId] = useState("");

  const [catlist, setcatlist ] = useState([]);

  const [valcat, setvalCat] = useState(false);

  // const [btntext, setbtntext] = useState("Add City");

  function EditCat(id) {
    const array = catlist.filter((cat) => cat.catid === id);

    setCategory(array[0].catname);

    setCatId(id);

  }

  function DeleteCity(id) {
    if (window.confirm("Are you sure!!! to Delete it?")) {
      axios
        .delete(baseUrl + `/DeleteCategory/${id}`)
        .then((res) => {
          toast.success(res.data);
          GetCategories();
          ClearAll();
        })
        .catch((err) => {
          console.log(err);
        });
    }
  }

  useEffect(() => {
    GetCategories();
  }, []);


  function AddCategory() {
    debugger;
    const data = {catname: catname};

    if (catname === "" || catname === " " || catname === "  ") {
      setvalCat(true);
    } else {
      axios
        .post(baseUrl + "/AddCategory", data)
        .then((res) => {
          debugger;
          toast.success(res.data)
          GetCategories();
          ClearAll();
        })
        .catch((error) => {
          console.log(error);
        });
    }
  }

  function GetCategories()
  {
    axios.get(baseUrl+"/GetCategories")
    .then(res=>
      {
        setcatlist(res.data)
      })
      .catch((error) => {
        console.log(error);
      });
  }


  function EditCities() {
    debugger;
    const data = {catname: catname, catid:catid};

    if (catname === "" || catname === " " || catname === "  ") {
      setvalCat(true);
    } else {
      debugger;
      axios
        .put(baseUrl + "/EditCategory", data)
        .then((res) => {
          debugger;
          toast.success(res.data);
          GetCategories();
          ClearAll();
        })
        .catch((error) => {
          console.log(error);
        });
    }
  }

  function ClearAll()
  {
    setCatId("");
    setCategory("");
  }

  return (
    <div>
      <div className="container mt-5">
        <div className="row">
          <div className="col-lg-6">
            <div className="card ">
              <div className="card-header">
                <h3 className="card-title">Add Category</h3>
              </div>
              <form className="emp-form">
                <div className="card-body">
                  <div className="form-row"></div>

                  <div className="form-group">
                    <label>Enter Category</label>
                    <input
                      type="text"
                      className="form-control"
                      name="apmcname"
                      required
                      value={catname}
                      onChange={(e) => setCategory(e.target.value)}
                    />
                  </div>
                  <div>
                    {valcat && (
                      <small className="text-danger">Enter Event Category</small>
                    )}
                  </div>
                </div>

                <div className="card-footer">
                  <div className="form-row">
                    <div className="form-group ">
                      <button
                        type="button"
                        className="btn btn-primary pull-right"
                        onClick={catid?EditCities:AddCategory}
                      >
                        {catid ? "Update Category" : "Add Category"}
                      </button>
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>

          <div className="col-lg-6">
            <div className="card">
              <div className="card-header">
                <h3 className="panel-title">Added Categories</h3>
              </div>
              <div className="card-body">
                <table className="table">
                  <tr>
                    <th>Category Id</th>
                    <th>Category Name</th>
                    <th></th>
                    <th></th>
                  </tr>
                  <tbody>
                    {catlist.map((cat, index) => {
                      return (
                        <tr key={index}>
                          <td>{cat.catid}</td>
                          <td>{cat.catname}</td>
                          <td>
                            <FiEdit
                              onClick={() => EditCat(cat.catid)}
                              style={{ cursor: "pointer" }}
                              color="green"
                              size={"1.5rem"}
                            ></FiEdit>
                          </td>
                          <td>
                            <RiDeleteBin5Line
                              style={{ cursor: "pointer" }}
                              color="red"
                              size={"1.5rem"}
                              onClick={() => DeleteCity(cat.catid)}
                            ></RiDeleteBin5Line>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
