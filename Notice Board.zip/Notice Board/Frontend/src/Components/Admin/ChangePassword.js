import axios from 'axios';
import React, { useEffect, useState } from 'react';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import { toast } from 'react-toastify';
import { baseUrl } from '../../App';


export default function ChangePassword({show, toggle,userid}) { 

  console.log(userid);

  const [input, setInput] = useState({
    oldpassword:'',
    newpassword:'',
    id:''
  })



  const handleChange = (e) => {
    setInput({ ...input, [e.target.name]: e.target.value })
  }

  useEffect(()=>
  {

    ClearAll();

    // const id = sessionStorage.getItem('userid')
    // setInput({...input, id:id})

  },[show])

  function HandlePassword()
  {
    // const id=sessionStorage.getItem('userid')
    setInput({id:userid})

    console.log(input);

    toast.promise(axios.put(baseUrl+`/ChangeAdminPass/${userid}`,input),{pending:'Updating.....'})
    .then(res=>{
      toast.success(res.data);
      toggle();
      ClearAll();
    }).catch(err=>
      {
        console.log(err);
        toast.error(err.response.data) 
      })
  }

  function ClearAll()
  {
    setInput({
      id:'',oldpassword:'',newpassword:''
    })
  }

  return (
    <>

      <Modal show={show} onHide={toggle}>
        <Modal.Header closeButton>
          <Modal.Title>Change Password</Modal.Title>
        </Modal.Header>
        <Modal.Body>
        <div className="form-group">
          <label className="form-label">Old Password</label>
          <input type="password" className="form-control" name="oldpassword" value={input.oldpassword} onChange={handleChange}/>
          </div>
          <div className="form-group">
          <label className="form-label">New Password</label>
          <input type="password" className="form-control" name="newpassword" value={input.newpassword} onChange={handleChange}/>
          </div>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={toggle}>
            Close
          </Button>
          <Button variant="primary" onClick={HandlePassword}>
            Save
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
}