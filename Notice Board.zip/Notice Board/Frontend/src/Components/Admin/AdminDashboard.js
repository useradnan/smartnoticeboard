import React from 'react'
import { Outlet } from 'react-router-dom'
import AdminHeader from './AdminHeader'

export default function AdminDashboard() {
  return (
    <div>
      <AdminHeader/>
      <Outlet />
    </div>
  )
}
