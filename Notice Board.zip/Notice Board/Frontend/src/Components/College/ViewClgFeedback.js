import axios from "axios";
import React, { useEffect, useState } from "react";
import { Col, Container, ListGroup, Row } from "react-bootstrap";
import { baseUrl } from "../../App";

export default function ViewClgFeedback() {
  const [feedbackList, setFeedbackList] = useState([]);

  useEffect(() => {
    debugger;
    axios
      .get(baseUrl + "/GetFeedback")
      .then((res) => {
        debugger;
        setFeedbackList(res.data);
      })
      .catch((err) => {
        console.log(err);
      });
  }, []);

  return (
    <Container>
      <Row className='my-5'>
        <Col>
        <div className="card">
              <div className="card-header">
                <h3 className="panel-title">Feedbacks</h3>
              </div>
              <div className="card-body text-center">
                <table className="table">
                  <tr>
                    <th>User Name</th>
                    <th>User Mobile</th>
                    <th>Department Name</th>
                    <th>Feedback</th>
                  </tr>
                  <tbody>
                    {feedbackList.filter(feedback=>String(feedback.clgid)===sessionStorage.getItem('userid'))
                    .map((feedback, index) => {
                      return (
                        <tr key={index}>
                          <td>{feedback.name}</td>
                          <td>{feedback.mobile}</td>
                          <td>{feedback.departmentname}</td>
                          <td>{feedback.feedback}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
        </Col>
      </Row>
    </Container>
  );
}
