import axios from "axios";
import React, { useEffect, useState } from "react";
import { FiEdit } from "react-icons/fi";
import { RiDeleteBin5Line } from "react-icons/ri";
import { toast } from "react-toastify";
import { baseUrl } from "../../App";

export default function ManageStaff() {
  const [disable, setDisable] = useState(false);

  const [departmentid, setDepartmentId] = useState("");

  const [staffname, setStaffName] = useState("");

  const [staffid, setStaffId] = useState("");

  const [staffrole, setStaffRole] = useState("");

  const [slno, setSlNo] = useState("");

  const [validdpt, setvaliddpt] = useState(false);
  const [validsname, setvalidsname] = useState(false);
  const [validsid, setvalidsid] = useState(false);
  const [validsrole, setvalidsrole] = useState(false);

  const [dptlist, setdptlist] = useState([]);
  const [stafflist, setStaffList] = useState([]);

  useEffect(() => {
    GetDepartments();
    GetStaff();
  }, []);

  function GetDepartments() {
    axios
      .get(baseUrl + "/GetDepartments")
      .then((res) => {
        setdptlist(res.data);
        console.log(res.data);
      })
      .catch((err) => {
        console.log(err);
      });
  }

  function SetStaffDetails(staff) {
    setStaffId(staff.staffid);
    setStaffName(staff.staffname);
    setStaffRole(staff.staffrole);
    setDepartmentId(staff.departmentid);
    setDisable(true)
  }

  function AddStaff() {
    if (departmentid === "") {
      setvaliddpt(true);
    } else if (staffid === "") {
      setvalidsid(true);
    } else if (staffname === "") {
      setvalidsname(true);
    } else if (staffrole === "") {
      setvalidsrole(true);
    } else {
      const clgid = sessionStorage.getItem("userid");
      const data = {
        staffid: staffid,
        staffname: staffname,
        clgid: clgid,
        staffrole: staffrole,
        departmentid: departmentid,
        
      };
      toast
        .promise(axios.post(baseUrl + "/AddStaff", data), {
          pending: "Adding.......",
        })
        .then((res) => {
          toast.success(res.data);
          GetStaff();
          ClearAll();
        })
        .catch((error) => {
          toast.error(error.response.data);
          console.log(error);
        });
    }
  }

  function DeleteStaff(staffid) {
    debugger;
    axios
      .delete(baseUrl + `/DeleteStaff/${staffid}`)
      .then((res) => {
        toast.warning(res.data);
        GetStaff();
      })
      .catch((error) => {
        console.log(error);
        toast.error(error.response.data);
      });
  }

  function GetStaff() {
    axios
      .get(baseUrl + "/GetStaff")
      .then((res) => {
        setStaffList(res.data);
        console.log(res.data);
      })
      .catch((error) => {
        console.log(error);
      });
  }


  function UpdateStaff() {
    if (departmentid === "") {
      setvaliddpt(true);
    } else if (staffid === "") {
      setvalidsid(true);
    } else if (staffname === "") {
      setvalidsname(true);
    } else if (staffrole === "") {
      setvalidsrole(true);
    } else {
      const clgid = sessionStorage.getItem("userid");
      const data = {
        staffid: staffid,
        staffname: staffname,
        clgid: clgid,
        staffrole: staffrole,
        departmentid: departmentid,
        
      };
      toast
        .promise(axios.put(baseUrl + "/EditStaff", data), {
          pending: "Updating.......",
        })
        .then((res) => {
          toast.success(res.data);
          GetStaff();
          ClearAll();
        })
        .catch((error) => {
          toast.error(error.response.data);
          console.log(error);
        });
    }
  }

  function ClearAll() {
    setvaliddpt(false);
    setvalidsid(false);
    setvalidsname(false);
    setvalidsrole(false);
    setDepartmentId("");
    setStaffId("");
    setStaffName("");
    setStaffRole("");
    staffid("");
  }

  return (
    <div>
      <div className="container-fluid mt-5">
        <div className="row">
          <div className="col-md-6">
            <div className="card">
              <div className="card-header">
                <h3>Add Staff</h3>
              </div>
              <div className="card-body">
                <div className="from-row">
                  <div className="form-group">
                    <label htmlFor="select" className="mt-3 mb-1">
                      Select Department:
                    </label>
                    <select
                      id=""
                      className="form-select text-center"
                      name="userType"
                      onChange={(e) => setDepartmentId(e.target.value)}
                      value={departmentid}
                    >
                      <option className="form-control" value={0}>
                        ----Select Department----
                      </option>
                      {dptlist
                        .filter(
                          (dpt) =>
                            String(dpt.clgid) ===
                            sessionStorage.getItem("userid")
                        )
                        .map((element, index) => {
                          return (
                            <option
                              className="form-control"
                              key={index}
                              value={element.departmentid}
                            >
                              {element.departmentname}
                            </option>
                          );
                        })}
                    </select>
                    {validdpt && (
                      <small id="useridhelp" className="text-danger">
                        Select Department
                      </small>
                    )}
                  </div>
                  <div className="form-group">
                    <label htmlFor="name" className="mt-3 mb-1">
                      Enter Staff ID:
                    </label>
                    <input
                      type="text"
                      className="form-control"
                      disabled={disable}
                      value={staffid}
                      onChange={(e) => setStaffId(e.target.value)}
                    />
                    {validsid && (
                      <small id="useridhelp" className="text-danger">
                        Enter Staff ID
                      </small>
                    )}
                  </div>
                  <div className="form-group">
                    <label htmlFor="name" className="mt-3 mb-1">
                      Enter Staff Name:
                    </label>
                    <input
                      type="text"
                      className="form-control"
                      value={staffname}
                      onChange={(e) => setStaffName(e.target.value)}
                    />
                    {validsname && (
                      <small id="useridhelp" className="text-danger">
                        Enter Staff Name
                      </small>
                    )}
                  </div>
                  <div className="form-group">
                    <label htmlFor="role" className="mt-3 mb-1">
                      Enter Staff Role:
                    </label>
                    <input
                      type="text"
                      className="form-control"
                      value={staffrole}
                      onChange={(e) => setStaffRole(e.target.value)}
                    />
                    {validsrole && (
                      <small id="useridhelp" className="text-danger">
                        Enter Staff Role
                      </small>
                    )}
                  </div>
                </div>
              </div>
              <div className="card-footer">
                <button
                  className="btn btn-primary float-end"
                  onClick={disable?UpdateStaff:AddStaff}
                >
                  {disable ? "Update Staff" : "Add Staff"}
                </button>
              </div>
            </div>
          </div>

          <div className="col-lg-6">
            <div className="card">
              <div className="card-header">
                <h3 className="panel-title">Existing Staff</h3>
              </div>
              <div className="card-body">
                <table className="table">
                  <tr>
                    <th>Staff Id</th>
                    <th>Staff Name</th>
                    <th>Staff Role</th>
                    <th>Staff Department</th>
                    <th></th>
                    <th></th>
                  </tr>
                  <tbody>
                    {stafflist
                      .filter(
                        (dpt) =>
                          String(dpt.clgid) === sessionStorage.getItem("userid")
                      )
                      .map((stf, index) => {
                        return (
                          <tr key={index}>
                            <td>{stf.staffid}</td>
                            <td>{stf.staffname}</td>
                            <td>{stf.staffrole}</td>
                            <td>{stf.departmentname}</td>
                            <td>
                              <FiEdit
                                onClick={() => SetStaffDetails(stf)}
                                style={{ cursor: "pointer" }}
                                color="green"
                                size={"1.5rem"}
                              ></FiEdit>
                            </td>
                            <td>
                              <RiDeleteBin5Line
                                style={{ cursor: "pointer" }}
                                color="red"
                                size={"1.5rem"}
                                onClick={() => DeleteStaff(stf.staffid)}
                              ></RiDeleteBin5Line>
                            </td>
                          </tr>
                        );
                      })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
