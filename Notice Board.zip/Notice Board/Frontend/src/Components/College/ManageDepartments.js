import axios from "axios";
import React, { useEffect, useState } from "react";
import { FiEdit } from "react-icons/fi";
import { RiDeleteBin5Line } from "react-icons/ri";
import { toast } from "react-toastify";
import { baseUrl } from "../../App";

export default function ManageDepartments() {

  const [clgid, setClgId] = useState("");

  useEffect(() => {
    const collegeid = sessionStorage.getItem('userid');
    setClgId(collegeid);
    GetDepartments();
  }, []);
  console.log(clgid);
  
  const [departmentname, setdepartmentname] = useState("");

  const [departmentid, setdepartmentid] = useState("");

  

  const [slno, setSlNo] = useState("");

  const [checkedit, setcheckedit] = useState(false);

  const [valdname, setvaldname] = useState(false);

  const [valdid, setvaldid] = useState(false);

  const [dptlist, setdptlist] = useState([]);

  

  function SetDpt(departmentid) {
    const array = dptlist.filter((dpt) => dpt.departmentid === departmentid);
    setdepartmentid(array[0].departmentid);
    setdepartmentname(array[0].departmentname);
    setcheckedit(true)
  }

  function DeleteDpt(departmentid) {
    if (window.confirm("Are you sure!!! to Delete it?")) {
      axios
        .delete(baseUrl + `/DeleteDpt/${departmentid}`)
        .then((res) => {
          toast.success(res.data);
          GetDepartments();
          ClearAll();
        })
        .catch((err) => {
          console.log(err);
        });
    }
  }

  function GetDepartments() {
    axios
      .get(baseUrl + "/GetDepartments")
      .then((res) => {
        setdptlist(res.data);
        console.log(res.data);
      })
      .catch((err) => {
        console.log(err);
      });
  }

  function AddDpt() {
    debugger;
    const cid = sessionStorage.getItem('userid');
    const data = {
      departmentid: departmentid,
      departmentname: departmentname,
      clgid:cid
    };
    if (departmentid === "") {
        setvaldid(true);}
    else if (departmentname === "") {
      setvaldname(true);
    } else {
      axios
        .post(baseUrl + `/AddDepartments`, data)
        .then((res) => {
          debugger;
          toast.success(res.data);
          GetDepartments();
          ClearAll();
        })
        .catch((error) => {
          console.log(error);
          toast.error(error.response.data)
        });
    }
  }

  function EditDpt() {
    debugger;
    const data = {
      departmentname: departmentname,
      slno:slno,
      departmentid:departmentid
    };

    if (departmentname === "") {
      setvaldname(true);
    } else {
      axios
        .put(baseUrl + "/EditDepartment", data)
        .then((res) => {
          debugger;
          toast.success(res.data);
          GetDepartments();
          ClearAll();
        })
        .catch((error) => {
          console.log(error);
        });
    }
  }

  function ClearAll() {
    setdepartmentname("");
    setdepartmentid("");
    setSlNo("");
    setvaldname(false);
    setvaldid(false);
  }
  return (
    <div>
      <div className="container mt-5">
        <div className="row">
          <div className="col-lg-6">
            <div className="card ">
              <div className="card-header">
                <h3 className="card-title">Add Departments</h3>
              </div>
              <form className="emp-form">
                <div className="card-body">
                  <div className="form-row"></div>

                  <div className="form-group mt-3">
                    <label className="mb-2">Enter Department ID</label>
                    <input
                      type="text"
                      className="form-control"
                      name="departmentid"
                      required
                      value={departmentid}
                      onChange={(e) => setdepartmentid(e.target.value)}
                      disabled={checkedit}
                    />
                    {valdid && (
                      <small id="useridhelp" className="form-text text-danger">
                        Enter Department ID
                      </small>
                    )}
                  </div>

                  <div className="form-group mt-3">
                    <label className="mb-2">Enter Department Name</label>
                    <input
                      type="text"
                      className="form-control"
                      name="departmentname"
                      required
                      value={departmentname}
                      onChange={(e) => setdepartmentname(e.target.value)}
                    />
                    {valdname && (
                      <small id="useridhelp" className="form-text text-danger">
                        Enter Department Name
                      </small>
                    )}
                  </div>
                </div>

                <div className="card-footer">
                  <div className="form-row">
                    <div className="d-flex gap-3 justify-content-end">
                      <button
                        type="button"
                        className="btn btn-primary"
                        onClick={EditDpt}
                      >
                        Update Department
                      </button>

                      <button
                        type="button"
                        className="btn btn-primary"
                        onClick={AddDpt}
                      >
                        Add Department
                      </button>
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>

          <div className="col-lg-6">
            <div className="card">
              <div className="card-header">
                <h3 className="panel-title">Added Departments</h3>
              </div>
              <div className="card-body">
                <table className="table">
                  <tr>
                    <th>Department Id</th>
                    <th>Department Name</th>
                    <th></th>
                    <th></th>
                  </tr>
                  <tbody>
                    {dptlist.filter(dpt=>String(dpt.clgid) === clgid)
                    .map((dpt, index) => {
                      return (
                        <tr key={index}>
                          <td>{dpt.departmentid}</td>
                          <td>{dpt.departmentname}</td>
                          <td>
                            <FiEdit
                              onClick={() => SetDpt(dpt.departmentid)}
                              style={{ cursor: "pointer" }}
                              color="green"
                              size={"1.5rem"}
                            ></FiEdit>
                          </td>
                          <td>
                            <RiDeleteBin5Line
                              style={{ cursor: "pointer" }}
                              color="red"
                              size={"1.5rem"}
                              onClick={() => DeleteDpt(dpt.departmentid)}
                            ></RiDeleteBin5Line>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
