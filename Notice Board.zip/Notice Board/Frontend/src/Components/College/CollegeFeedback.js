import React from 'react'

export default function CollegeFeedback() {
  return (
    <div>
      
    </div>
  )
}
