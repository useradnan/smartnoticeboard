import axios from "axios";
import React, { useEffect, useState } from "react";
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import { toast } from "react-toastify";
import { baseUrl } from "../../App";

export default function UpdateProfile({ show, toggle, clgid }) {
  console.log(clgid);

  const [cities, setCities] = useState([]);

  const [valcity, setValcity] = useState(false);
  const [valclgname, setValClgName] = useState(false);
  const [valclgmob, setValClgMob] = useState(false);

  const [input, setInput] = useState({
    cityid: "",
    clgmob: "",
    clgname: "",
  });

  const handleChange = (e) => {
    setInput({ ...input, [e.target.name]: e.target.value });
  };

  useEffect(() => {
    ClearAll();
    GetCities();
  }, [show]);

  function GetCities() {
    axios
      .get(baseUrl + "/GetCities")
      .then((res) => {
        setCities(res.data);
      })
      .catch((error) => {
        console.log(error);
      });
  }

  function Update() {
    debugger
    if(input.cityid===undefined || input.cityid==="" )
    {
      setValcity(true)
    }
    else if(input.clgname===undefined || input.clgname==="")
    {
      setValClgName(true)
    }
    else if(input.clgmob===undefined || input.clgmob==="")
    {
      setValClgMob(true)
    }
    else
    {
    toast
      .promise(axios.put(baseUrl + `/UpdateClgProfile/${clgid}`, input), {
        pending: "Updating.....",
      })
      .then((res) => {
        toast.success(res.data);
        toggle();
        ClearAll();
      })
      .catch((err) => {
        console.log(err);
        toast.error(err.response.data);
      });
    }
  }

  function ClearAll() {

    setValClgMob(false)
    setValClgMob(false)
    setValcity(false)

    setInput({
      cityid: "",
      clgname: "",
      clgmob: "",
    });

    
  }

  console.log(input);

  return (
    <>
      <Modal show={show} onHide={toggle}>
        <Modal.Header closeButton>
          <Modal.Title>Update Profile</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <div className="form-group mt-3">
            <label htmlFor="select">Select City</label>
            <select
              className="form-select text-center"
              name="cityid"
              value={input.cityid}
              onChange={handleChange}
            >
              <option className="form-control" value={0}>
                ----Select City----
              </option>
              {cities.map((element, index) => {
                return (
                  <option
                    className="form-control"
                    key={index}
                    value={element.cityid}
                  >
                    {element.cityname}
                  </option>
                );
              })}
            </select>
            {valcity && (
              <small id="useridhelp" className="form-text text-danger">
                Select City
              </small>
            )}
          </div>
          <div className="form-group mt-3">
            <label className="form-label">College Name</label>
            <input
              type="text"
              className="form-control"
              name="clgname"
              value={input.clgname}
              onChange={handleChange}
            />
            {valclgname && (
              <small id="useridhelp" className="form-text text-danger">
                Enter College Name
              </small>
            )}
          </div>
          <div className="form-group mt-3">
            <label className="form-label">College Mob.</label>
            <input
              type="number"
              className="form-control"
              name="clgmob"
              value={input.clgmob}
              onChange={handleChange}
            />
            {valclgmob && (
              <small id="useridhelp" className="form-text text-danger">
                Enter College Mobile No.
              </small>
            )}
          </div>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={toggle}>
            Close
          </Button>
          <Button variant="primary" onClick={Update}>
            Save
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
}
