import axios from "axios";
import React, { useEffect, useState } from "react";
import { Container, Row, Col, Card, Button, Form } from "react-bootstrap";
import { RiDeleteBin5Line } from "react-icons/ri";
import { toast } from "react-toastify";
import { baseUrl } from "../../App";

export default function PostNews() {
  const [newstitle, setNewsTitle] = useState("");
  const [newsdesc, setNewsDesc] = useState("");
  const [newsList, setNewsList] = useState([]);

useEffect(()=>
{
    GetNews()
},[])

  const handleSubmit = (e) => {
    e.preventDefault();
    if (newstitle === "" || newsdesc === "") {
      toast.error("Field can't be empty!!!!");
    } else {
      const data = {
        newstitle: newstitle,
        newsdesc: newsdesc,
        clgid: sessionStorage.getItem("userid"),
      };

      axios
        .post(baseUrl + "/AddNews", data)
        .then((res) => {
          toast.success(res.data);
          setNewsTitle("");
          setNewsDesc("");
        })
        .catch((err) => {
          console.log(err);
        });
    }
  };

  function GetNews()
  {
    axios.get(baseUrl+'/GetNews')
    .then(res=>{
        setNewsList(res.data)
    }).catch(err=>{
        console.log(err);
    })
  }

  function DeleteNews(newsid)
  {
    axios.delete(baseUrl+`/DeleteNews/${newsid}`)
    .then(res=>{
        toast.error(res.data);
        GetNews();
    }).catch(err=>{
        console.log(err);
    })
  }

  return (
    <Container>
      <Row className="mt-5">
        <Col>
          <h1>College News</h1>
        </Col>
      </Row>
      <Row>
        <Col>
          <Form onSubmit={handleSubmit}>
            <Form.Group controlId="title">
              <Form.Label>Title</Form.Label>
              <Form.Control
                type="text"
                value={newstitle}
                onChange={(e) => setNewsTitle(e.target.value)}
              />
            </Form.Group>

            <Form.Group controlId="content">
              <Form.Label>Content</Form.Label>
              <Form.Control
                as="textarea"
                rows={3}
                value={newsdesc}
                onChange={(e) => setNewsDesc(e.target.value)}
              />
            </Form.Group>

            <Button variant="primary" className="mt-3" type="submit">
              Submit
            </Button>
          </Form>
        </Col>
      </Row>
      <Row className='my-5'>
        <Col>
        <div className="card">
              <div className="card-header">
                <h3 className="panel-title">News</h3>
              </div>
              <div className="card-body">
                <table className="table">
                  <tr>
                    <th>News Id</th>
                    <th>News Title</th>
                    <th>News Description</th>
                    <th></th>
                  </tr>
                  <tbody>
                    {newsList.map((news, index) => {
                      return (
                        <tr key={index}>
                          <td>{news.newsid}</td>
                          <td>{news.newstitle}</td>
                          <td>{news.newsdesc}</td>
                          <td>
                            <RiDeleteBin5Line
                              style={{ cursor: "pointer" }}
                              color="red"
                              size={"1.5rem"}
                              onClick={() => DeleteNews(news.newsid)}
                            ></RiDeleteBin5Line>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>

          {/* {newsList.map((news, index) => (
            <Card key={index} className="my-3">
              <Card.Body>
                <Card.Title>{news.newsid}</Card.Title>
                <Card.Title>{news.newstitle}</Card.Title>
                <Card.Text>{news.newsdesc}</Card.Text>
              </Card.Body>
            </Card>
          ))} */}

        </Col>
      </Row>
    </Container>
  );
}
