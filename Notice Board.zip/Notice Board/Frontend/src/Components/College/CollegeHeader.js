import React, { useState } from 'react'
import { Container, Nav, Navbar } from 'react-bootstrap'
import { Link } from 'react-router-dom'
import ChangeClgPassword from './ChangeClgPassword';
import UpdateProfile from './UpdateProfile';


export default function CollegeHeader() {

  const id = sessionStorage.getItem('userid');

  const [show, setShow] = useState(false);

  const toggle = () => setShow(!show);

  const [show1, setShow1] = useState(false);

  const toggle1 = () => setShow1(!show1);


  return (
    <div>
      <Navbar collapseOnSelect expand="lg" bg="dark" variant="dark">
        <Container fluid>
          <Navbar.Brand href="/">College Dashboard</Navbar.Brand>
          <Navbar.Toggle aria-controls="responsive-navbar-nav" />
          <Navbar.Collapse id="responsive-navbar-nav">
            <Nav className="me-auto">
              <Nav.Link onClick={toggle1} className="ms-1">Update Profile</Nav.Link>
              <UpdateProfile show={show1} toggle={toggle1} clgid={id}/>
              <Nav.Link as={Link} to='/ClgDash/ManageDepartments' className="ms-1">Manage Departments</Nav.Link>
              <Nav.Link as={Link} to='/ClgDash/ManageStaff' className="ms-1">Manage Staff</Nav.Link>
              <Nav.Link as={Link} to='/ClgDash/ManageEvents' className="ms-1">Manage Events</Nav.Link>
              <Nav.Link as={Link} to='/ClgDash/PostNews' className="ms-1">Manage News</Nav.Link>
              <Nav.Link as={Link} to='/ClgDash/ViewClgFeedback' className="ms-1">View Feedback</Nav.Link>
              <Nav.Link onClick={toggle} className="ms-1" >Change Password</Nav.Link>
              <ChangeClgPassword show={show} toggle={toggle} userid={id}/>
            </Nav>
            <Nav>
              <Nav.Link as={Link} to='/' className="me-1">Logout</Nav.Link>
            </Nav>
          </Navbar.Collapse>
        </Container>
      </Navbar>
    </div>
  )
}
