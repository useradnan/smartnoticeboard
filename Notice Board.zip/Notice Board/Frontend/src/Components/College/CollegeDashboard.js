import axios from "axios";
import React, { useEffect, useState } from "react";
import { Outlet } from "react-router-dom";
import { baseUrl } from "../../App";
import CollegeHeader from "./CollegeHeader";

export default function CollegeDashboard() {


  const [clglist, setclglist] = useState([]);

  const [id, setId] = useState("");

  const [name, setname] = useState("");

  useEffect(() => {
    GetColleges();
  }, []);


  useEffect(() => {
    filtereffect();
  }, [clglist]);

  function GetColleges() {
    axios
      .get(baseUrl + "/GetCollege")
      .then((res) => {
        setclglist(res.data);
        console.log(clglist);
      })
      .catch((err) => {
        console.log(err);
      });
  }

  function filtereffect() {
    
    const uid = sessionStorage.getItem('userid')
    const filteredClg = clglist.filter(
      (colleges) => String(colleges.clgid) === uid
    );
    console.log(filteredClg);
    setname(filteredClg[0]?.clgname);
  }

  return (
    <div>
      <CollegeHeader />
      <h5 style={{color:"green",}} className="float-end me-4 ">Welcome: {name}</h5>

      
      <Outlet />
    </div>
  );
}
