import { logDOM } from "@testing-library/react";
import axios from "axios";
import React, { useEffect, useState } from "react";
import { Container, Row, Col, Form, Button } from "react-bootstrap";
import { FiEdit } from "react-icons/fi";
import { RiDeleteBin5Line } from "react-icons/ri";
import { toast } from "react-toastify";
import { baseUrl } from "../../App";

export default function ManageEvents() {
  const [eventname, setEventName] = useState("");
  const [eventdesc, setEventDesc] = useState("");
  const [eventdate, setEventDate] = useState("");
  const [eventtime, setEventTime] = useState("");
  const [catid, setCatId] = useState("");
  const [validated, setValidated] = useState(false);
  const [isValidSelect, setValidSelect] = useState(true);

  const [file, setImages] = useState([]);

  const [eventlist, seteventlist] = useState([]);

  const [catlist, setCatList] = useState([]);

  useEffect(() => {
    GetEvents();
    GetCategories();
  }, []);

  const handleSubmit = (event) => {
    // debugger;
    const form = event.currentTarget;
    event.preventDefault();
    if (form.checkValidity() === false) {
      console.log(form.checkValidity());
      console.log("stopPropagation");
      event.stopPropagation();
      setValidated(true);
    } else {
      debugger;
      // code to submit event information to database
      const clgid = sessionStorage.getItem("userid");
      const data = {
        eventname: eventname,
        eventdesc: eventdesc,
        eventdate: eventdate,
        eventtime: eventtime,
        catid: catid,
        clgid: clgid,
      };
      console.log(data);
      axios
        .post(baseUrl + "/AddEvent", data)
        .then((res) => {
          UploadImage(res.data.eventid);
          ClearAll();
          GetEvents();
        })
        .catch((err) => {
          console.log(err);
        });
    }
    //   setValidated(true);
  };

  function UploadImage(eventid) {
    const formdata = new FormData();
    for (let i = 0; i < file.length; i++) {
      formdata.append("images", file[i]);
    }

    axios
      .post(baseUrl + `/UploadImage/${eventid}`, formdata, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      })
      .then((res) => {
        toast.success(res.data);
        console.log(res);
      })
      .catch((err) => {
        console.log(err);
      });
  }

  function ClearAll() {
    const myForm = document.getElementById("myForm");
    myForm.reset();
    setValidated(false);
    setEventName("");
    setEventDesc("");
    setEventDate("");
    setEventTime("");
  }

  function GetEvents() {
    axios.get(baseUrl + "/GetAllEvents").then((res) => {
      seteventlist(res.data);
    }).catch(err=>{
      console.log(err);
    });
  }

  function DeleteEvent(eventid) {
    debugger;
    axios
      .delete(baseUrl + `/DeleteEvent/${eventid}`)
      .then((res) => {
        toast.warning(res.data);
        GetEvents();
      })
      .catch((error) => {
        console.log(error);
        toast.error(error.response.data);
      });
  }

  function GetCategories() {
    axios
      .get(baseUrl + "/GetCategories")
      .then((res) => {
        setCatList(res.data);
      })
      .catch((error) => {
        console.log(error);
      });
  }

  console.log(eventlist);
  console.log(catlist);

  return (
    <Container className="mt-5">
      <Row>
        <Col>
          <h3>Add Event</h3>
          <Form
            noValidate
            validated={validated}
            onSubmit={handleSubmit}
            id="myForm"
          >
            <Form.Group controlId="eventName">
              <Form.Label>Select Event Category</Form.Label>
              <Form.Select
                required
                type="text"
                value={catid}
                onChange={(event) => setCatId(event.target.value)}
              >
                <option className="form-control" value={0}>
                  ----Select City----
                </option>
                {catlist.map((element, index) => {
                  return (
                    <option
                      className="form-control"
                      key={index}
                      value={element.catid}
                    >
                      {element.catname}
                    </option>
                  );
                })}
              </Form.Select>
            </Form.Group>
            <Form.Group controlId="eventName">
              <Form.Label>Event Name</Form.Label>
              <Form.Control
                required
                type="text"
                value={eventname}
                onChange={(event) => setEventName(event.target.value)}
                placeholder="Enter event name"
              />
              <Form.Control.Feedback type="invalid">
                Please enter an event name.
              </Form.Control.Feedback>
            </Form.Group>
            <Form.Group controlId="eventDescription">
              <Form.Label>Event Description</Form.Label>
              <Form.Control
                as="textarea"
                rows={3}
                required
                value={eventdesc}
                onChange={(event) => setEventDesc(event.target.value)}
                placeholder="Enter event description"
              />
              <Form.Control.Feedback type="invalid">
                Please enter an event description.
              </Form.Control.Feedback>
            </Form.Group>
            <Form.Group controlId="eventDate">
              <Form.Label>Event Date</Form.Label>
              <Form.Control
                required
                type="date"
                value={eventdate}
                onChange={(event) => setEventDate(event.target.value)}
              />
              <Form.Control.Feedback type="invalid">
                Please enter a valid event date.
              </Form.Control.Feedback>
            </Form.Group>
            <Form.Group controlId="eventTime">
              <Form.Label>Event Time</Form.Label>
              <Form.Control
                required
                type="time"
                value={eventtime}
                onChange={(event) => setEventTime(event.target.value)}
              />
              <Form.Control.Feedback type="invalid">
                Please enter a valid event time.
              </Form.Control.Feedback>
            </Form.Group>

            <Form.Group controlId="eventimage">
              <Form.Label>Event Image</Form.Label>
              <Form.Control
                required
                type="file"
                onChange={(event) => setImages([...event.target.files])}
                multiple
              />
              <Form.Control.Feedback type="invalid">
                Please select file.
              </Form.Control.Feedback>
            </Form.Group>

            <Button type="submit" className="mt-4">
              Create Event
            </Button>
          </Form>
        </Col>
      </Row>

      <div className="form-row mt-5">
        <div className="col">
          <div className="card">
            <div className="card-header">
              <h3 className="panel-title">Added Events</h3>
            </div>
            <div className="card-body">
              <table className="table">
                <tr>
                  <th>Event Id</th>
                  <th>Event Name</th>
                  <th>Event Desc</th>
                  <th>Event Date</th>
                  <th>Event Time</th>
                  <th></th>
                </tr>
                <tbody>
                  {eventlist
                    .filter(
                      (event) =>
                        String(event.clgid) === sessionStorage.getItem("userid")
                    )
                    .map((event, index) => {
                      return (
                        <tr key={index}>
                          <td>{event.eventid}</td>
                          <td>{event.eventname}</td>
                          <td>{event.eventdesc}</td>
                          <td>{event.eventdate}</td>
                          <td>{event.eventtime}</td>
                          <td>
                            <RiDeleteBin5Line
                              style={{ cursor: "pointer" }}
                              color="red"
                              size={"1.5rem"}
                              onClick={() => DeleteEvent(event.eventid)}
                            ></RiDeleteBin5Line>
                          </td>
                        </tr>
                      );
                    })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </Container>
  );
}
