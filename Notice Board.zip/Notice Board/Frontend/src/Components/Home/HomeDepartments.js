import React from 'react'

export default function HomeDepartments() {
  return (
    <div>
      Hiiiii
    </div>
  )
}
