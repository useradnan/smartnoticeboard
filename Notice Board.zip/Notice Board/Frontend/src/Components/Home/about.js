import React from 'react';
import { Container, Row, Col, Image } from 'react-bootstrap';
import image from '../../assets/about.jpg'

export default function About(){
  return (
    <Container>
      <Row>
        <Col className='d-flex justify-content-center my-3'>
          <Image  src={image} alt="Smart Notice Board Logo"  height={400} width={900}/>
        </Col>
      </Row>
      <Row>
        <Col>
          <h1>About Smart Notice Board</h1>
          <p>Smart Notice Board is a web application that helps users keep track of important information and announcements. Our app is designed to be simple, intuitive, and user-friendly.</p>
          <p>With Smart Notice Board, you can create notices, reminders, and announcements in just a few clicks. You can customize the appearance of your notices with different colors, fonts, and styles. You can also schedule notices to appear at specific times and dates, so you never forget an important event.</p>
          <p>Our app is perfect for businesses, schools, and organizations of all sizes. Whether you need to share information with your employees, students, or members, Smart Notice Board makes it easy.</p>
          <p>Try Smart Notice Board today and see how it can improve your communication and organization!</p>
        </Col>
      </Row>
    </Container>
  );
};
