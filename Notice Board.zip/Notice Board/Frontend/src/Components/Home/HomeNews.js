import axios from "axios";
import React, { useEffect, useState } from "react";
import { Container } from "react-bootstrap";
import { baseUrl } from "../../App";

export default function HomeNews() {
  const [newsList, setNewsList] = useState([]);

  useEffect(() => {
    GetNews();
  }, []);

  function GetNews() {
    axios
      .get(baseUrl + "/GetNews")
      .then((res) => {
        setNewsList(res.data);
      })
      .catch((err) => {
        console.log(err);
      });
  }

  console.log(newsList);
  return (
    <Container>
      <div className="form-row mt-5">
        <div className="col">
          <div className="card">
            <div className="card-header text-center">
              <h3 className="panel-title">News</h3>
            </div>
            <div className="card-body">
              <table className="table text-center">
                <tr className="text-danger">
                  <th>College</th>
                  <th>News Title</th>
                  <th>News Description</th>
                </tr>
                <tbody>
                  {newsList
                    .map((news, index) => {
                      return (
                        <tr key={index}>
                          <td>{news.clgname}</td>
                          <td>{news.newstitle}</td>
                          <td>{news.newsdesc}</td>
                        </tr>
                      );
                    })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </Container>
  );
}
