import React from "react";
import Container from "react-bootstrap/Container";
import Nav from "react-bootstrap/Nav";
import Navbar from "react-bootstrap/Navbar";
import { Link } from "react-router-dom";

export default function AppHeader() {
  return (
    <div>
      <Navbar collapseOnSelect expand="lg" bg="dark" variant="dark">
        <Container fluid>
          <Navbar.Brand href="/">Notice Board</Navbar.Brand>
          <Navbar.Toggle aria-controls="responsive-navbar-nav" />
          <Navbar.Collapse id="responsive-navbar-nav">
            <Nav className="me-auto">
              <Nav.Link as={Link} to='/HomeClg'>Colleges</Nav.Link>
              <Nav.Link as={Link} to='/HomeEvents'>Events</Nav.Link>
              <Nav.Link as={Link} to='/HomeNews'>News</Nav.Link>
              {/* <Nav.Link as={Link} to='/HomeDepartments'>Departments</Nav.Link> */}
              <Nav.Link as={Link} to='/Feedback'>Feedback</Nav.Link>
              {/* <Nav.Link href="/">Services</Nav.Link> */}
              <Nav.Link as={Link} to='/About'>About</Nav.Link>
            </Nav>
            <Nav>
              <Nav.Link as={Link} to='/Login'>Login</Nav.Link>
              {/* <Nav.Link eventKey={2} href="/">
                Dank memes
              </Nav.Link> */}
            </Nav>
          </Navbar.Collapse>
        </Container>
      </Navbar>
    </div>
  );
}
