import axios from "axios";
import React, { useEffect, useState } from "react";
import { Container, Row, Col, Form, Button, Alert } from "react-bootstrap";
import { toast } from "react-toastify";
import { baseUrl } from "../../App";

export default function PublicFeedback() {
  const [clgid, setClgId] = useState("");
  const [departmentid, setDepartment] = useState("");
  const [feedback, setFeedback] = useState("");
  const [name, setName] = useState('');
  const [mobile, setMobile] = useState('');
  const [clglist, setClgList] = useState([]);
  const [dptlist, setDptList] = useState([]);
  // const [filterlist, setFilterList] = useState([]);


  const handleSubmit = (e) => {
    e.preventDefault();
    const data = {
      clgid:clgid,
      departmentid:departmentid,
      feedback:feedback,
      mobile:mobile,
      name:name
    }
    debugger;
    if(clgid==="" ||departmentid==="" || feedback==="" || name==="" || mobile ==="" )
    {
      toast.error("Fields Can't be Empty!!!! ");
    }
    else{
      axios.post(baseUrl+'/PostFeedback',data)
      .then(res=>{
        toast.success(res.data);
      setClgId("");
      setDepartment("");
      setFeedback("");
      setName("");
      setMobile("");
      }).catch(err=>{
        console.log(err);
      })
    }
  };

  useEffect(() => {
    GetColleges();
    GetDepartments();
  }, []);

  // useEffect(() => {
  //   setFilterList(dptlist.filter(dpt=>dpt.clgid === Number(clgid)))
  // }, [clgid]);

  function GetColleges() {
    axios
      .get(baseUrl + "/GetCollege")
      .then((res) => {
        setClgList(res.data);
        // console.log(res.data);
      })
      .catch((err) => {
        console.log(err);
      });
  }

  function GetDepartments() {
    axios
      .get(baseUrl + "/GetDepartments")
      .then((res) => {
        setDptList(res.data);
        // console.log(res.data);
      })
      .catch((err) => {
        console.log(err);
      });
  }
  return (
    <Container>
      <Row className="mt-3">
        <Col md={{ span: 6, offset: 3 }}>
          <h1>College Feedback</h1>
          <Form onSubmit={handleSubmit}>

          <Form.Group controlId="name">
              <Form.Label>Name</Form.Label>
              <Form.Control type="text" value={name} onChange={(e)=>setName(e.target.value)} />
            </Form.Group>
            <Form.Group controlId="mobile" className="mt-2">
              <Form.Label>Mobile Number</Form.Label>
              <Form.Control type="tel" value={mobile} onChange={(e)=>setMobile(e.target.value)} />
            </Form.Group>

            <Form.Group controlId="college" className="mt-2">
              <Form.Label>College</Form.Label>
              <Form.Control
                as="select"
                value={clgid}
                onChange={(e) => setClgId(e.target.value)}
              >
                <option value="">Select College</option>
                {clglist.map((element, index) => {
                  return (
                    <option
                      className="form-control"
                      key={index}
                      value={element.clgid}
                    >
                      {element.clgname}
                    </option>
                  );
                })}
              </Form.Control>
            </Form.Group>

            <Form.Group controlId="department" className="mt-2">
              <Form.Label>Department</Form.Label>
              <Form.Control
                as="select"
                value={departmentid}
                onChange={(e) => setDepartment(e.target.value)}
              >
                <option value="">Select Department</option>
                {dptlist
                  .filter((dpt) => dpt.clgid === Number(clgid))
                  .map((element, index) => {
                    return (
                      <option
                        className="form-control"
                        key={index}
                        value={element.departmentid}
                      >
                        {element.departmentname}
                      </option>
                    );
                  })}
              </Form.Control>
            </Form.Group>

            <Form.Group controlId="feedback" className="mt-2">
              <Form.Label>Feedback</Form.Label>
              <Form.Control
                as="textarea"
                rows={3}
                value={feedback}
                onChange={(e) => setFeedback(e.target.value)}
              />
            </Form.Group>
            <Button variant="primary" className="mt-3" type="submit">
              Submit
            </Button>
          </Form>
        </Col>
      </Row>
    </Container>
  );
}
