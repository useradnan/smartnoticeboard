import axios from "axios";
import React, { useEffect, useState } from "react";
import { Card, Carousel, Col, Container, Row } from "react-bootstrap";
import { baseUrl } from "../../App";

export default function HomeEvents() {
  const [eventlist, seteventlist] = useState([]);

  useEffect(() => {
    GetEvents();
  }, []);

  function GetEvents() {
    axios
      .get(baseUrl + "/GetAllEvents")
      .then((res) => {
        seteventlist(res.data);
      })
      .catch((err) => {
        console.log(err);
      });
  }
  console.log(eventlist);
  return (
    <Container>
      <Row md={2}>
        {eventlist.map((event) => {
          return (
            <Col key={event.eventid} className="">
              <Card className="my-3" >
                {/* <Card.Header className="bg-info">
              <h3>{event.eventname}</h3>
            </Card.Header> */}
                <ImageComponent event={event} />
                <Card.Body style={{height:'50vh', overflowY:'scroll'}}>
                  <h3 className="text-info">{event.eventname}</h3>
                  {/* <Card.Title>{event.eventname}</Card.Title> */}
                  <Row className="my-2">
                    <Col>
                      <Card.Text>
                        <b>College Name :</b> {event.clgname}
                      </Card.Text>
                    </Col>
                    <Col className="d-flex justify-content-end">
                      <Card.Text><b>Category : </b>{event.catname}</Card.Text>
                    </Col>
                  </Row>
                  <Row className="my-2">
                    <Col>
                      <Card.Text><b>Event Dat :</b> {event.eventdate}</Card.Text>
                    </Col>
                    <Col className="d-flex justify-content-end">
                      <Card.Text><b>Event Time :</b> {event.eventtime}</Card.Text>
                    </Col>
                  </Row>
                  <Row className="my-2">
                    <Col xs={12}>
                      <Card.Text >
                        <b>Event Description :</b> {event.eventdesc}
                      </Card.Text>
                    </Col>
                  </Row>
                </Card.Body>
              </Card>
            </Col>
          );
        })}
      </Row>
    </Container>
  );
}

function ImageComponent({ event }) {
  const [images, setImages] = useState([]);

  useEffect(() => {
    GetImages(event.eventid);
  }, [event.eventid]);

  function GetImages(eventid) {
    axios
      .get(baseUrl + `/GetImagesByEvent/${eventid}`)
      .then((res) => {
        setImages(res.data);
      })
      .catch((err) => {
        console.log(err);
      });
  }

  return (
    <Carousel>
      {images.map((image) => (
        <Carousel.Item key={image.imageid}>
          <img
            className="d-block w-100"
            src={image}
            alt="First slide"
            height={300}
            width={250}
          />
        </Carousel.Item>
      ))}
    </Carousel>
  );
}
