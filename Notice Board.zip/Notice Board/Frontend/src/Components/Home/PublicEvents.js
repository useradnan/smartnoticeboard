import React from 'react'

export default function PublicEvents() {
  return (
    <div>
      
    </div>
  )
}
