import axios from "axios";
import React, {useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { baseUrl } from "../../App";

export default function Login() {
  const arr = ["Admin", "College"];

  const [usertype, setUsertype] = useState("");

  const [userid, setUserId] = useState("");

  const [password, setPassword] = useState("");

  const navigate = useNavigate();

  const [valpword, setValpword]= useState(false);

  const [valut, setValut]= useState(false);

  const [valun, setValun]= useState(false);

  console.log(userid);
  console.log(password);
  console.log(usertype);

  function Login()
  {
    debugger;

    if(usertype==="")
    {
      setValut(true)
    }
   if(userid==="")
    {
      setValun(true)
    }
     if(password==="")
    {
      setValpword(true)
    }
    else{

      debugger;
    const data ={userid:userid, password:password, usertype:usertype};

    axios.post(baseUrl+'/Login',data).then(res=>{

      sessionStorage.setItem("userid",userid);
      
      if(usertype==="Admin")
      {
        navigate("/AdminDash")
      }
      else if(usertype==="College")
      {
        navigate("/ClgDash")
      }
      toast.success("Logged in successfully")
    }).catch(err=>{
      console.log(err);
      toast.error(err.response.data)
    })

    }

    
  }

  return (
    <div className="col-md-4 offset-md-7 mt-5">
      <div className="card">
        <div className="card-header">
          <h3>Login Form</h3>
        </div>
        <div className="card-body">
          <form>
            <div className="form-group">
              <label htmlFor="select">Select Usertype</label>
              <select
                className="form-select text-center"
                name="userType"
                onChange={(e) => setUsertype(e.target.value)}
                defaultValue={0}
              >
                <option className="form-control" value={0}>
                  ----Select User Type----
                </option>
                {arr.map((element, index) => {
                  return (
                    <option
                      className="form-control"
                      key={index}
                      value={element}
                    >
                      {element}
                    </option>
                  );
                })}
              </select>
              {
                valut && <small id="useridhelp" className="form-text text-danger">
                Select Usertype
              </small>
              }
              
            </div>
            <div className="form-group mt-3">
              <label htmlFor="exampleInputEmail1">User ID</label>
              <input
                type="text"
                className="form-control"
                id="userid"
                aria-describedby="useridhelp"
                placeholder="Enter user id"
                value={userid}
                onChange={(e) => setUserId(e.target.value)}
              />
              {
                valun && <small id="useridhelp" className="form-text text-danger">
                Enter User ID
              </small>
              }
              
            </div>
            <div className="form-group mt-3">
              <label htmlFor="password">Password</label>
              <input
                type="password"
                className="form-control"
                id="password"
                placeholder="Enter Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
              {
                valpword && <small id="passwordhelp" className="form-text text-danger">
                Enter Password
              </small>
              }
              
            </div>
          </form>
          {/* <p className="mt-3"> Not a member? <a href="#table">Register </a></p> */}
        </div>
        <div className="card-footer">
          <button type="button" className="btn btn-primary float-end" onClick={Login}>
            Login
          </button>
        </div>
      </div>
    </div>
  );
}
