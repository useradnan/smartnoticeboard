import axios from "axios";
import React, { useEffect, useState } from "react";
import { Button, Collapse } from "react-bootstrap";
import { Link } from "react-router-dom";
import { baseUrl } from "../../App";

export default function HomeColleges() {
  const [clglist, setclglist] = useState([]);

  const [dptlist, setDptList] = useState([]);

  const [open, setOpen] = useState(false);

  useEffect(() => {
    GetColleges();
  }, []);

  function GetColleges() {
    axios
      .get(baseUrl + "/GetCollege")
      .then((res) => {
        setclglist(res.data);
        console.log(res.data);
      })
      .catch((err) => {
        console.log(err);
      });
  }

  function GetDpt(clgid) {
    debugger;
    setOpen(!open);
    axios
      .get(baseUrl + `/GetDepartment/${clgid}`)
      .then((res) => {
        setDptList(res.data);
        console.log(res.data);
      })
      .catch((err) => {
        console.log(err);
      });
  }

  console.log(clglist);
  console.log(dptlist);

  return (
    <div>
      <div className="col-md-8 offset-md-2 mt-5">
        <div className="card">
          <div className="card-header">
            <h3 className="panel-title text-center">Colleges</h3>
          </div>
          <div className="card-body">
            <table className="table text-center">
              <tr className="text-danger">
                {/* <th>College Id</th> */}
                <th>College Name</th>
                <th>College City</th>
                <th>College Mobile</th>
                <th></th>
              </tr>
              <tbody>
                {clglist.map((clg, index) => {
                  return (
                    <tr key={index}>
                      {/* <td>{clg.clgid}</td> */}
                      <td>{clg.clgname}</td>
                      <td>{clg.cityname}</td>
                      <td>{clg.clgmob}</td>
                      <td>
                        <Button
                          variant="link"
                          onClick={() => GetDpt(clg.clgid)}
                        >
                          View Departments
                        </Button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
            </div>
            <Collapse in={open}>
            <table className="table text-center">
              <tr className="text-danger">
                <th>Department ID</th>
                <th>Department Name</th>
              </tr>
              <tbody>
                {dptlist.map((dpt, index) => {
                  return (
                    <tr key={index}>
                      <td>{dpt.departmentid}</td>
                      <td>{dpt.departmentname}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
            </Collapse>
          
        </div>
      </div>
    </div>
  );
}
